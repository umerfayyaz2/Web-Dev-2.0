for (let i = 1; i <= 3; i++) {
    setTimeout(function() {
      console.log(i); // Output: 1, 2, 3
    }, 1000);
  }